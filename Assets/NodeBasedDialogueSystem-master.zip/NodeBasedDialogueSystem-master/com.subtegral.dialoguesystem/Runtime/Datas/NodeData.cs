﻿using System;
using UnityEngine;

namespace Subtegral.DialogueSystem.DataContainers
{
    [Serializable]
    public class NodeData
    {
        public string nodeType;
        public string nodeGUID;
    }
}