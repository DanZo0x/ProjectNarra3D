﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEditor.Experimental.GraphView;
using UnityEngine;


namespace Subtegral.DialogueSystem.Editor
{
    public class SetAffinityNode : NodeGraph
    {
        public string TargetName;
        public int Value;
        
    }
}

