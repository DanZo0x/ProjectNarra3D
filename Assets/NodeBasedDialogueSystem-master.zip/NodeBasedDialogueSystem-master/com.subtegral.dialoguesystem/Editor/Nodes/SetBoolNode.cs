﻿using Subtegral.DialogueSystem.DataContainers;
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEditor.Experimental.GraphView;
using UnityEngine;



namespace Subtegral.DialogueSystem.Editor
{
    public class SetBoolNode : NodeGraph
    {
        public string Property;
        public bool Value;

    }
}

