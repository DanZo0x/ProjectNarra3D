﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEditor.Experimental.GraphView;
using UnityEngine;


namespace Subtegral.DialogueSystem.Editor
{
    public class ConditionNode : NodeGraph
    {
        public string Property;
        public bool PropertyValue;
        
    }
}

